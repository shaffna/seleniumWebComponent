package SeleniumWebComponent.WebComponent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class datepickerAutomation {
	static WebDriver driver;

	public static void main(String[] args) {
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://jqueryui.com/datepicker/");

		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));

		driver.findElement(By.id("datepicker")).click();

		driver.findElement(By.className("ui-datepicker-next")).click();

		driver.findElement(By.xpath("//a[text()='22']")).click();

		String selectedDate = driver.findElement(By.id("datepicker")).getAttribute("value");
		System.out.println("Selected Date: " + selectedDate);

		waitForFixTime(5000);

		driver.quit();

	}

	public static void waitForFixTime(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
