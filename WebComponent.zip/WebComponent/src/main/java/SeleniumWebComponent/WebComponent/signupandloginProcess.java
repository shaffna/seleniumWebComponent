package SeleniumWebComponent.WebComponent;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class signupandloginProcess {
	static WebDriver driver;

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.guvi.in/");

		driver.findElement(By.linkText("Sign up")).click();

		driver.findElement(By.id("name")).sendKeys("fed");
		driver.findElement(By.id("email")).sendKeys("testlogin3@gmail.com");
		driver.findElement(By.id("password")).sendKeys("login@1234");
		driver.findElement(By.id("mobileNumber")).sendKeys("9999456789");
		driver.findElement(By.id("signup-btn")).click();
		WebElement profileDropdown = driver.findElement(By.id("profileDrpDwn"));
		Select profileSelect = new Select(profileDropdown);
		profileSelect.selectByVisibleText("Student");
		WebElement degreeDropdown = driver.findElement(By.id("degreeDrpDwn"));
		Select degreeSelect = new Select(degreeDropdown);
		degreeSelect.selectByVisibleText("B.E. / B.Tech. Computer Science");
		driver.findElement(By.id("year")).sendKeys("2023");

		driver.findElement(By.linkText("Submit")).click();
		System.out.println("Signup process completed. Please activate your account through the email.");
		driver.findElement(By.xpath("//a//img")).click();

		driver.findElement(By.linkText("Login")).click();

		driver.findElement(By.id("email")).sendKeys("testlogin3@gmail.com");
		driver.findElement(By.id("password")).sendKeys("login@1234");
		driver.findElement(By.id("login-btn")).click();

		String loginPageTitle = driver.getTitle();
		System.out.println("Login Page Title: " + loginPageTitle);
		driver.quit();
	}
}
